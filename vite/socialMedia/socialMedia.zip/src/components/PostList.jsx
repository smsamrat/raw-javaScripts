import Post from "./Post"
function PostList(){
    return(
        <>
            <Post></Post>
            <Post></Post>
            <Post></Post>
        </>
    )
}
export default PostList;